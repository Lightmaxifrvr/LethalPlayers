# LethalPlayers

**I AM IN NO WAY AFFILIATED WITH BIZZLEMIP**
this project is open source just like biggerlobby

# CHANGELOG

**0.5.4/5/6**

(damm i really cant do a simple change XD)
Changed the LC-API version and changed a few strings here and there.
**ITS RECCOMENDED THAT UDATE TO AVOID HAVING ISSUES!**


**0.5.3**

This version just changed some things in this readme and also
**THIS VERSION IS CROSS COMPATIBLE**


**0.5.1/2**

Minor : Increased Player Count from 20 to 50
(hopefully wont break anything)

# NOTES

 HOW THE FUCK DID THIS BLOW UP SO FAST XDDDD

 [Lethal Company Modding Discord](https://discord.com/invite/GVVFX2cd)